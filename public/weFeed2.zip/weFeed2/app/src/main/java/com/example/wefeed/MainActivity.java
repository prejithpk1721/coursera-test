package com.example.wefeed;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout mNavDrawer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.drawer_layout);


    }

    public void btn_Contr(View view) {
        startActivity(new Intent(getApplicationContext(), ContributerInformation.class));
    }

    public void btn_Req(View view) {
        startActivity(new Intent(getApplicationContext(), ReceiverRegistration.class));
    }


}
