package com.example.wefeed;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().setTitle("Login");

    }

    public void btn_signupForm(View view) {
        startActivity(new Intent(getApplicationContext(), Signup_form.class));
    }

    public void btn_requestForm(View view) {
        startActivity(new Intent(getApplicationContext(), MainActivity.class));
    }

    public void btn_forgotPass(View view) {
        startActivity(new Intent(getApplicationContext(), Forgot_password.class));
    }

}
